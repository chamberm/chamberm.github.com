#include "Model.h"

#include "GLInclude.h"

Model::Model()
{}

//////////////////////////////////////////////////////////////////////////

Model::Model(const vector<Vector3>& aVertices, 
             const vector<Triangle>& aTriangles, 
             unsigned int aGLId)
: mVertices(aVertices)
, mTriangles(aTriangles)
, mGLId(aGLId)
{}

//////////////////////////////////////////////////////////////////////////

void Model::DrawMesh()
{
    //DO NOT MODIFY THIS METHOD

    //Material setup
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mMat.Ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mMat.Diffuse);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR,mMat.Specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS,mMat.Shininess);

    //Mesh, to the batmobile!
    glCallList(mGLId);
}

//////////////////////////////////////////////////////////////////////////

void Model::Init()
{}
