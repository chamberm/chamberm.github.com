#include "StencilShadowRender.h"

void InitRendering()
{
}

void RenderScene(Model& aShadowCaster, Model& aSceneGeometry)
{
    aShadowCaster.DrawMesh();
    aSceneGeometry.DrawMesh();
}
