#ifndef STENCILSHADOWRENDER_H_
#define STENCILSHADOWRENDER_H_

#include "Model.h"
#include "GLInclude.h"

//Called once when the program launches.
void InitRendering();

//Called once every frame
void RenderScene(Model& aShadowCaster, Model& aSceneGeometry);

#endif //STENCILSHADOWRENDER_H_
